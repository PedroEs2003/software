import static org.junit.Assert.*;
import org.junit.Test;

public class BeverageInputValidatorTest
{
    @Test
    public void testInvalidNameContainsNumbers() {
        assertFalse(BeverageInputValidator.validateInput("Coffee123,6,12,24"));
    }



    @Test
    public void testInvalidInputWithSpecialCharacters() {
        assertFalse(BeverageInputValidator.validateInput("Café Latte,6,12,24"));
    }

        @Test
        public void testInvalidInputWithNegativeSize() {
            assertFalse(BeverageInputValidator.validateInput("Espresso,-6,12,24"));
        }

        @Test
        public void testInvalidInputWithDuplicateSizes() {
            assertFalse(BeverageInputValidator.validateInput("Latte,6,12,12,24"));
        }

        @Test
        public void testInvalidInputWithNonNumericSizes() {
            assertFalse(BeverageInputValidator.validateInput("Mocha,6,12,a,24"));
        }

        @Test
        public void testValidInputWithLargeSizes() {
            assertTrue(BeverageInputValidator.validateInput("Latte,6,12,24,36,48"));
        }



    @Test
    public void testInvalidNameWithNoCommaSeparator() {
        assertFalse(BeverageInputValidator.validateInput("Espresso12"));
    }

    @Test
    public void testInvalidNameWithCommaAtTheEnd() {
        assertFalse(BeverageInputValidator.validateInput("Latte,"));
    }



    @Test
    public void testInvalidInputWithZeroSize() {
        assertFalse(BeverageInputValidator.validateInput("Tea,0,6,12"));
    }

    @Test
    public void testInvalidInputWithLargeSize() {
        assertFalse(BeverageInputValidator.validateInput("Tea,6,12,50"));
    }



    @Test
    public void testInvalidNameLengthUnder2Chars() {
        assertFalse(BeverageInputValidator.validateInput("C,1,2,3"));
    }



    @Test
    public void testValidSizeInRange() {
        assertTrue(BeverageInputValidator.validateInput("Macchiato,1,24,48"));
    }

    @Test
    public void testInvalidSizeIsInteger() {
        assertFalse(BeverageInputValidator.validateInput("Mocha,1,2.5,3"));
    }

    @Test
    public void testInvalidSizesInAscendingOrder() {
        assertFalse(BeverageInputValidator.validateInput("Americano,3,2,1"));
    }

    @Test
    public void testValidOneToFiveSizes() {
        assertTrue(BeverageInputValidator.validateInput("Latte,5"));
        assertTrue(BeverageInputValidator.validateInput("Latte,1,2,3,4,5"));
        assertFalse(BeverageInputValidator.validateInput("Latte,1,2,3,4,5,6"));
    }

    @Test
    public void testValidInput() {
        assertTrue(BeverageInputValidator.validateInput("Cappuccino,6,12,24"));
    }

    @Test
    public void testInvalidInputEmptyString() {
        assertFalse(BeverageInputValidator.validateInput(""));
    }

    @Test
    public void testInvalidInputNull() {
        assertFalse(BeverageInputValidator.validateInput(null));
    }

    @Test
    public void testInvalidNameContainsSpecialCharacters() {
        assertFalse(BeverageInputValidator.validateInput("Chai!Latte,6,12,24"));
    }

    @Test
    public void testInvalidNameExactlyFifteenCharsLong() {
        assertFalse(BeverageInputValidator.validateInput("VanillaCaramelLatte,6,12,24"));
    }

    @Test
    public void testInvalidDuplicateSizes() {
        assertFalse(BeverageInputValidator.validateInput("Mocha,8,8,12"));
    }

    @Test
    public void testInvalidMaxSizeExceeded() {
        assertFalse(BeverageInputValidator.validateInput("Tea,6,24,49"));
    }

    @Test
    public void testInvalidNegativeSize() {
        assertFalse(BeverageInputValidator.validateInput("Tea,6,-12,24"));
    }

    @Test
    public void testInvalidSizeNonNumeric() {
        assertFalse(BeverageInputValidator.validateInput("Juice,6,12a,24"));
    }

    @Test
    public void testValidInputWithLeadingWhitespace() {
        assertTrue(BeverageInputValidator.validateInput(" Green Tea,6,12,24"));
    }

    @Test
    public void testValidInputWithWhitespace() {
        assertTrue(BeverageInputValidator.validateInput(" Black Tea , 1 , 2, 3 "));
    }

    @Test
    public void testInvalidNoRepeatedSizes() {
        assertFalse(BeverageInputValidator.validateInput("Tea,6,6,12,24"));
    }

    @Test
    public void testValidReceiveList() {
        assertTrue(BeverageInputValidator.validateInput("Smoothie,12,24,36"));
    }

    @Test
    public void testValidNonEmptyList() {
        assertTrue(BeverageInputValidator.validateInput("Latte,8"));
    }

    @Test
    public void testValidMultipleBeverageSizes() {
        assertTrue(BeverageInputValidator.validateInput("Iced Tea,6,12"));
    }
}
