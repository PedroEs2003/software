//
//  ParkingViewModel.swift
//  ParkiUDLAP
//
//  Created by Aldo Serrano Rugerio on 06/05/24.
//

import Foundation
import FirebaseDatabase
import FirebaseDatabaseSwift

class ParkingViewModel: ObservableObject {
    var ref = Database.database().reference()
    @Published var parkingSpots: [Bool] = Array(repeating: false, count: 14) // Assuming 14 spots for simplicity

    func readPark(parkName: String) {
        ref.child("parking_spots").observe(.value) { snapshot in
            var spots = Array(repeating: false, count: 14) // Reset the spots
            for child in snapshot.children {
                if let childSnapshot = child as? DataSnapshot,
                   let value = childSnapshot.value as? [String: Bool],
                   let occupied = value["occupied"] {
                    if let index = Int(childSnapshot.key) {
                        spots[index] = occupied
                    }
                }
            }
            DispatchQueue.main.async {
                self.parkingSpots = spots
            }
        }
    }
}
