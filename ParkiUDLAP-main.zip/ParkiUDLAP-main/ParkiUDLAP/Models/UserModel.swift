//
//  UserModel.swift
//  ParkiUDLAP
//
//  Created by Aldo Serrano Rugerio on 26/04/24.
//


import Foundation

struct User: Identifiable, Codable
{
    let id: String
    let name: String
    let email: String
    let userID: String
    
    var initials: String
    {
        let formatter = PersonNameComponentsFormatter()
        if let components = formatter.personNameComponents(from: name)
        {
            formatter.style = .abbreviated
            return formatter.string(from: components)
        }
        return ""
    }
}

extension User
{
    static var MOCK_USR = User(id: NSUUID().uuidString, name:  "Steve Jobs", email: "stevejobs@apple.com", userID: "101010")
}
