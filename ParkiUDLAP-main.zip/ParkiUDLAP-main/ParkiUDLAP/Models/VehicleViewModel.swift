//
//  VehicleViewModel.swift
//  ParkiUDLAP
//
//  Created by Aldo Serrano Rugerio on 30/04/24.
//

import Foundation
import FirebaseAuth
import FirebaseFirestore
import FirebaseFirestoreSwift

struct VehicleModel: Identifiable
{
    var id: String
    var VehicleType: String
    var Brand: String
    var Model: String
    var Plates: String
    var OwnersName: String
    var AuthorsID: String
}
final class VehicleViewModel: ObservableObject
{
    
    @Published var vehicles: [VehicleModel] = []
    private let path: String = "vehicles"
    
    init()
    {
        fetchVehicles()
    }
    
    func fetchVehicles()
    {
        vehicles.removeAll()
        let user = Auth.auth().currentUser
        let database = Firestore.firestore()
        let reference = database.collection(path).whereField("AuthorsID", isEqualTo: user?.uid ?? "")
        reference.getDocuments
        {
            snapshot, error in
            guard error == nil else
            {
                print("Fatal error: \(error!.localizedDescription)")
                return
            }
            if let snapshot = snapshot
            {
                for document in snapshot.documents
                {
                    let data = document.data()
                    
                    let id = data["id"] as? String ?? ""
                    let vehicleType = data["VehicleType"] as? String ?? ""
                    let brand = data["Brand"] as? String ?? ""
                    let model = data["Model"] as? String ?? ""
                    let plates = data["Plates"] as? String ?? ""
                    let ownersName = data["OwnersName"] as? String ?? ""
                    let authorsID = data["AuthorsID"] as? String ?? ""
                    
                    let vehicle = VehicleModel(id: id, VehicleType: vehicleType, Brand: brand, Model: model, Plates: plates, OwnersName: ownersName, AuthorsID: authorsID)
                    self.vehicles.append(vehicle)
                }
            }
        }
    }
    
    func addVehicle(VehicleType: String, Brand: String, Model: String, Plates: String, OwnersName: String)
    {
        let user = Auth.auth().currentUser
        let database = Firestore.firestore()
        let reference = database.collection(path).document(Brand)
        reference.setData(["VehicleType": VehicleType,
                           "Brand": Brand,
                           "Model": Model,
                           "Plates": Plates,
                           "OwnersName": OwnersName,
                           "id": UUID().uuidString,
                           "AuthorsID": user?.uid ?? ""])
        {
            error in
            if let error = error
            {
                print(error.localizedDescription)
            }
        }
    }
}
