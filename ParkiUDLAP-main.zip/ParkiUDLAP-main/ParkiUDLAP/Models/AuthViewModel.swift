//
//  AuthViewModel.swift
//  ParkiUDLAP
//
//  Created by Aldo Serrano Rugerio on 26/04/24.
//

import Foundation
import Firebase
import FirebaseFirestoreSwift

protocol AuthenticationFormProtocol
{
    var formIsValid: Bool { get }
}

@MainActor
class AuthViewModel: ObservableObject
{
    @Published var userSession: FirebaseAuth.User?
    @Published var currentUser: User?
    
    init()
    {
        self.userSession = Auth.auth().currentUser
        Task
        {
            await fetchUserData()
        }
    }
    
    func signIn(withEmail email: String, password: String) async throws
    {
        do
        {
            let result = try await Auth.auth().signIn(withEmail: email, password: password)
            self.userSession = result.user
            await fetchUserData()
        }
        catch
        {
            print("Error al iniciar sesion: \(error.localizedDescription)")
        }
    }
    
    func createUser(withEmail email: String, password: String, name: String, userID: String) async throws
    {
        print("Registrando a nuevo usuario")
        do
        {
            let result = try await Auth.auth().createUser(withEmail: email, password: password)
            self.userSession = result.user
            let user = User(id: result.user.uid, name: name, email: email, userID: userID)
            let encodedUser = try Firestore.Encoder().encode(user)
            try await Firestore.firestore().collection("users").document(user.id).setData(encodedUser)
            await fetchUserData()
        }
        catch
        {
            print("Falla al crear usuario con error \(error.localizedDescription)")
        }
    }
    
    func signOut()
    {
        do
        {
            try Auth.auth().signOut() // Cierra la sesion del usuario en el backend Firebase
            self.userSession = nil // Limpia los datos de la sesion del usuario para llevarnos de vuelta a la pantalla de inicio de sesion
            self.currentUser = nil // Limpia los datos del usuario actual en el modelo de usuario
        }
        catch
        {
            print("Error al cerrar sesion: \(error.localizedDescription)")
        }
    }
    
    func deleteAccount()
    {
        
    }
    
    func fetchUserData() async
    {
        guard let uid = Auth.auth().currentUser?.uid else { return }
        guard let snapshot = try? await Firestore.firestore().collection("users").document(uid).getDocument() else { return }
        self.currentUser = try? snapshot.data(as: User.self)
    }
}
