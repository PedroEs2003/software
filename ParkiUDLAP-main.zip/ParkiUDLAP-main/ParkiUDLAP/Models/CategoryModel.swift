//
//  CategoryModel.swift
//  ParkiUDLAP
//
//  Created by Aldo Serrano Rugerio on 06/05/24.
//

import SwiftUI

struct CategoryModel: Identifiable, Hashable{
    var id: UUID = .init()
    var image: String
    var title: String
}

var categoryList: [CategoryModel] = [
    CategoryModel(image:"car.side.fill", title: "Coche"),
    CategoryModel(image:"scooter", title: "Scooter"),
    CategoryModel(image:"bicycle", title: "Bici"),
    CategoryModel(image:"truck.box.fill", title: "Camion"),
]
