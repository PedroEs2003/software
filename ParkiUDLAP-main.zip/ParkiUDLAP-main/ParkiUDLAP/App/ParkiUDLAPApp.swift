//
//  ParkiUDLAPApp.swift
//  ParkiUDLAP
//
//  Created by Aldo Serrano Rugerio on 18/04/24.
//

import SwiftUI
import Firebase

@main
struct ParkiUDLAPApp: App 
{
    @StateObject var viewModel = AuthViewModel()
    init()
    {
        FirebaseApp.configure()
        
    }
    var body: some Scene
    {
        WindowGroup 
        {
            MainView()
                .environmentObject(viewModel)
        }
    }
}
