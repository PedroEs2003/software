//
//  MenuView.swift
//  ParkiUDLAP
//
//  Created by Aldo Serrano Rugerio on 30/04/24.
//

import SwiftUI

struct MenuView: View 
{
    var body: some View 
    {
        TabView
        {
            HomeView()
                .tabItem{ Label("Principal", systemImage: "house.fill") }
                .tag(1)
            MapView()
                .tabItem { Label("Mapa", systemImage: "map") }
                .tag(2)
            TicketView()
                .tabItem{ Label("Pagar", systemImage: "creditcard.fill") }
                .tag(3)
            ContactsView()
                .tabItem{ Label("Contactos", systemImage: "book") }
                .tag(4)
            ReportView()
                .tabItem{ Label("Reportar", systemImage: "exclamationmark.triangle") }
                .tag(5)
            ProfileView()
                .tabItem{ Label("Perfil", systemImage: "person.circle") }
                .tag(6)
        }
    }
}

#Preview 
{
    MenuView()
        .environmentObject(AuthViewModel())
}
