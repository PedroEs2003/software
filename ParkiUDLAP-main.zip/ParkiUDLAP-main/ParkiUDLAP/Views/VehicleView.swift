//
//  VehicleView.swift
//  ParkiUDLAP
//
//  Created by Aldo Serrano Rugerio on 30/04/24.
//

import SwiftUI

struct VehicleView: View
{
    @StateObject var vehicleViewModel = VehicleViewModel()
    @Environment(\.dismiss) var dismiss
    var body: some View
    {
        NavigationStack
        {
            ZStack
            {
                LogInBackgroundView(offsetY: 100)
                VStack
                {
                    HStack
                    {
                        
                        Button
                        {
                            dismiss()
                        }
                        label:
                        {
                            Image(systemName: "chevron.backward")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 30, height: 30)
                                .foregroundStyle(.white)
                                .padding(.leading, 40)
                                .padding(.trailing, 55)
                        }
                        
                        Text("Mis Vehiculos")
                            .font(.title)
                            .bold()
                            .foregroundStyle(.white)
                        
                        Spacer()
                    }
                    .padding(.top, 40)
                    .padding(.bottom, 40)
                    
                    Spacer()
                    
                    ScrollView
                    {
                        ForEach(vehicleViewModel.vehicles)
                        {
                            vehicle in
                            Vehicle(vehicle: vehicle)
                        }
                    }
                    
                    Spacer()
                }
            }
        }
        .navigationBarBackButtonHidden()
    }
}

#Preview
{
    VehicleView()
}

struct Vehicle: View
{
    var vehicle: VehicleModel
    var body: some View
    {
        HStack
        {
            switch vehicle.VehicleType
            {
                case "Auto":
                    Image(systemName: "car")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 60, height: 60)
                        .padding()
                case "Motocicleta":
                    Image(systemName: "bicycle")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 60, height: 60)
                        .padding()
                case "SUV":
                    Image(systemName: "suv.side")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 60, height: 60)
                        .padding()
                default:
                    Image("")
            }
            VStack
            {
                Text("Marca: \(vehicle.Brand)")
                    .font(.callout)
                Text("Modelo: \(vehicle.Model)")
                    .font(.callout)
                Text("Placas: \(vehicle.Plates)")
                    .font(.callout)
                Text("Propietario: \(vehicle.OwnersName)")
                    .font(.callout)
            }
            
            Spacer()
        }
        .frame(width: 360, height: 120)
        .background(AppColors.customWhite)
        .clipShape(RoundedRectangle(cornerRadius: 20))
        .shadow(radius: 2)
    }
}
