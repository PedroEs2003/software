//
//  Contacts.swift
//  ParkiUDLAP
//
//  Created by Cecilia Soriano Tochimani on 28/04/24.
//

import SwiftUI

struct ContactsView: View {
    @State private var contacto: String = ""
    
    var body: some View {
        ZStack{
            Color(red:255/255, green: 250/255, blue: 250/250)
                .edgesIgnoringSafeArea(.all)
            VStack{
                Text("Contactos")
                    .font(.title)
                    .fontWeight(.bold)
                    .padding(.trailing, 210)
                    .padding(.bottom, 10.0)
                    .foregroundColor(.black)
                HStack{
                    Button(action: {
                        // Acción a realizar cuando se presiona el botón
                    }) {
                        Text("Seguridad")
                            .foregroundColor(.white)
                            .padding()
                            .background(Color(red: 26/255, green: 93/255, blue: 26/255).opacity(0.7))
                            .cornerRadius(10)
                    }
                    
                    Button(action: {
                        // Acción a realizar cuando se presiona el botón
                    }) {
                        Text("Emergencia")
                            .foregroundColor(.white)
                            .padding()
                            .background(Color(red: 26/255, green: 93/255, blue: 26/255).opacity(0.7))
                            .cornerRadius(10)
                    }
                    Button(action: {
                        // Acción a realizar cuando se presiona el botón
                    }) {
                        Text("Vialidad")
                            .foregroundColor(.white)
                            .padding()
                            .background(Color(red: 26/255, green: 93/255, blue: 26/255).opacity(0.7))
                            .cornerRadius(10)
                    }
                }
                Spacer()
                
                TextField("Buscar contacto", text: $contacto)
                    .padding(.horizontal, 10) // Agregar relleno horizontal
                    .padding(.vertical, 20.0) // Agregar relleno vertical
                    .background(Color.white)
                    .cornerRadius(20)
                    .padding(.horizontal, 30)
                
                VStack{
                    VStack{
                        Text("Seguridad")
                            .padding(.trailing, 220.0)
                            .fontWeight(.bold)
                        HStack{
                            Image(systemName: "phone")
                                .imageScale(.large)
                                .foregroundStyle(.black)
                            Text("6713608216")
                                .padding(.trailing, 210.0)
                        }
                        .padding(.bottom, 15)
                        Divider()
                    }
                    .padding(.vertical, 10)
                    
                    VStack{
                        Text("Emergencia")
                            .padding(.trailing, 220.0)
                            .fontWeight(.bold)
                        HStack{
                            Image(systemName: "phone")
                                .imageScale(.large)
                                .foregroundStyle(.black)
                            Text("8329218539")
                                .padding(.trailing, 220.0)
                        }
                        .padding(.bottom, 15)
                        Divider()
                    }
                    .padding(.vertical, 10)
                    
                    VStack{
                        Text("Vialidad")
                            .padding(.trailing, 240.0)
                            .fontWeight(.bold)
                        HStack{
                            Image(systemName: "phone")
                                .imageScale(.large)
                                .foregroundStyle(.black)
                            Text("8329218539")
                                .padding(.trailing, 220.0)
                        }
                        .padding(.bottom, 15)
                        Divider()
                    }
                    .padding(.vertical, 10)
                    
                    VStack{
                        Text("Colegio Residenciales")
                            .padding(.trailing, 140.0)
                            .fontWeight(.bold)
                        HStack{
                            Image(systemName: "phone")
                                .imageScale(.large)
                                .foregroundStyle(.black)
                            Text("8329218539")
                                .padding(.trailing, 220.0)
                        }
                        .padding(.bottom, 15)
                        Divider()
                    }
                    .padding(.vertical, 10)
                    
                    VStack{
                        Text("Servicios Médicos")
                            .padding(.trailing, 160.0)
                            .fontWeight(.bold)
                        HStack{
                            Image(systemName: "phone")
                                .imageScale(.large)
                                .foregroundStyle(.black)
                            Text("8329218539")
                                .padding(.trailing, 220.0)
                        }
                        .padding(.bottom, 15)
                        Divider()
                    }
                    .padding(.vertical, 10)
                    
                    VStack{
                        Text("Servicios Escolares")
                            .padding(.trailing, 140.0)
                            .fontWeight(.bold)
                        HStack{
                            Image(systemName: "phone")
                                .imageScale(.large)
                                .foregroundStyle(.black)
                            Text("8329218539")
                                .padding(.trailing, 220.0)
                        }
                        .padding(.bottom, 15)
                        Divider()
                    }
                    .padding(.vertical, 10)
                }
            }//HSTACK
        }//ZSTACK
        
    }
}

#Preview {
    ContactsView()
}

