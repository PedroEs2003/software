//
//  AddPaymentView.swift
//  ParkiUDLAP
//
//  Created by Cecilia Soriano Tochimani on 26/04/24.
//

import SwiftUI

struct AddPaymentView: View {
    @State private var nombre: String = ""
    @State private var ntarjeta: String = ""
    @State private var fecha: String = ""
    @State private var cvv: String = ""
    @State private var isChecked: Bool = false
    @Environment(\.dismiss) var dismiss
    var body: some View {
        NavigationStack{
            ZStack{
                Color(red:255/255, green: 250/255, blue: 250/250)
                    .edgesIgnoringSafeArea(.all)
                VStack{
                    HStack{
                        Button{
                            dismiss()
                        }label:{
                            Image(systemName: "chevron.backward")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 30, height: 30)
                                .padding(.trailing, 40)
                                .padding(.bottom, 60.0)
                        }
                        .tint(.black)
                        
                        Text("Agregar Tarjeta")
                            .font(.title)
                            .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
                            .padding(.trailing, 85)
                            .padding(.bottom, 60.0)
                    }
                    VStack{
                        Text("Método de pago")
                            .padding(.trailing, 200)
                        HStack{
                            Button(action: {
                                
                            }) {
                                Text("Pay Pal")
                                    .foregroundColor(.white)
                                    .padding()
                                    .background(Color(red: 26/255, green: 93/255, blue: 26/255))
                                    .cornerRadius(10)
                            }
                            Button(action: {
                                // Acción a realizar cuando se presiona el botón
                            }) {
                                Text("Crédito")
                                    .foregroundColor(.white)
                                    .padding()
                                    .background(Color(red: 26/255, green: 93/255, blue: 26/255))
                                    .cornerRadius(10)
                            }
                            Button(action: {
                                // Acción a realizar cuando se presiona el botón
                            }) {
                                Text("Débito")
                                    .foregroundColor(.white)
                                    .padding()
                                    .background(Color(red: 26/255, green: 93/255, blue: 26/255))
                                    .cornerRadius(10)
                            }
                        }
                        
                        TextField("Nombre", text: $nombre)
                            .padding(.horizontal, 20) // Agregar relleno horizontal
                            .padding(.vertical, 30.0) // Agregar relleno vertical
                            .background(Color.white)
                            .cornerRadius(20)
                            .padding(.horizontal, 30)
                        
                        TextField("Número de tarjeta", text: $ntarjeta)
                            .padding(.horizontal, 20) // Agregar relleno horizontal
                            .padding(.vertical, 30.0) // Agregar relleno vertical
                            .background(Color.white)
                            .cornerRadius(20)
                            .padding(.horizontal, 30)
                        
                        VStack{
                            HStack{
                                Text("Fecha de vencimiento")
                                    .foregroundColor(Color(red: 108/255, green: 102/255, blue: 102/255))
                                    .padding(.trailing, 80.0)
                                Text("CVV")
                                    .padding()
                                    .foregroundColor(Color(red: 108/255, green: 102/255, blue: 102/255))
                            }
                                HStack{
                                    TextField("", text: $fecha)
                                        .padding(.horizontal, 20) // Agregar relleno horizontal
                                        .padding(.vertical, 20.0) // Agregar relleno vertical
                                        .background(Color.white)
                                        .cornerRadius(20)
                                        .padding(.horizontal, 30)
                                    
                                    TextField("", text: $cvv)
                                        .padding(.horizontal, 20) // Agregar relleno horizontal
                                        .padding(.vertical, 20.0) // Agregar relleno vertical
                                        .background(Color.white)
                                        .cornerRadius(20)
                                        .padding(.horizontal, 30)
                                    
                                }
                            
                            HStack{
                                Toggle(isOn: $isChecked) {
                                        Text("Guardar tarjeta")
                                        .padding()
                                }
                                .padding(.horizontal, 25.0)
                            }
                            
                            Button(action: {
                                // Acción a realizar cuando se presiona el botón
                            }) {
                                Text("Confirmar")
                                    .foregroundColor(.white)
                                    .padding()
                                    .background(Color(red: 254/255, green: 122/255, blue: 54/255))
                                    .cornerRadius(20)
                                    .padding(.horizontal, 90.0)
                            }
                        }
                        
                    }
                    
                }// VSTACK PRINCIPAL
            } //ZSTACK
        }//NAVIGATION STACK
        .navigationBarBackButtonHidden()
    }
}

#Preview {
    AddPaymentView()
}
