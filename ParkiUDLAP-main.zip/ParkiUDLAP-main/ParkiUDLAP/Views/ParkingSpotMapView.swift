//
//  ParkingSpotMapView.swift
//  ParkiUDLAP
//
//  Created by Aldo Serrano Rugerio on 06/05/24.
//

import SwiftUI
import MapKit
import CoreLocation

struct ParkingSpotMapView: View {
    @StateObject private var viewModel = MapViewModel() // Use @StateObject for initialization

    var body: some View {
        Map(coordinateRegion: $viewModel.region,
            interactionModes: .all,
            showsUserLocation: true,
            userTrackingMode: $viewModel.userTrackingMode,
            annotationItems: viewModel.annotations) { location in
            MapMarker(coordinate: location.coordinate, tint: .blue)
        }
        .overlay(routeOverlay)
        .onAppear {
            viewModel.checkIfLocationServicesIsEnabled()
        }
    }

    private var routeOverlay: some View {
        Group {
            if let route = viewModel.route {
                MapRouteView(route: route)
            }
        }
    }
}

struct MapRouteView: View {
    let route: MKRoute

    var body: some View {
        GeometryReader { geometry in
            Path { path in
                let points = route.polyline.points()
                let pointCount = route.polyline.pointCount

                // Calculate bounding map rect and use it to scale points
                let boundingMapRect = route.polyline.boundingMapRect
                let mapRectWidth = boundingMapRect.size.width
                let mapRectHeight = boundingMapRect.size.height
                let origin = boundingMapRect.origin

                if pointCount > 0 {
                    // Convert the first point
                    let firstPoint = points[0]
                    let firstCGPoint = CGPoint(
                        x: ((firstPoint.coordinate.longitude - origin.x) / mapRectWidth) * geometry.size.width,
                        y: ((firstPoint.coordinate.latitude - origin.y) / mapRectHeight) * geometry.size.height
                    )
                    path.move(to: firstCGPoint)

                    // Convert and add the rest of the points
                    for index in 1..<pointCount {
                        let point = points[index]
                        let cgPoint = CGPoint(
                            x: ((point.coordinate.longitude - origin.x) / mapRectWidth) * geometry.size.width,
                            y: ((point.coordinate.latitude - origin.y) / mapRectHeight) * geometry.size.height
                        )
                        path.addLine(to: cgPoint)
                    }
                }
            }
            .stroke(Color.blue, lineWidth: 5)
        }
    }
}


struct AnnotationItem: Identifiable {
    let id = UUID()
    var coordinate: CLLocationCoordinate2D
}

class MapViewModel: NSObject, ObservableObject, CLLocationManagerDelegate {
    @Published var region = MKCoordinateRegion(
        center: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194),
        span: MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)
    )
    @Published var route: MKRoute?
    @Published var userTrackingMode = MapUserTrackingMode.follow
    @Published var annotations: [AnnotationItem] = []

    private let locationManager = CLLocationManager()
    private let destinationCoordinate = CLLocationCoordinate2D(latitude: 19.0555, longitude: -98.283) // Example destination

    override init() {
        super.init()
        locationManager.delegate = self
    }

    func checkIfLocationServicesIsEnabled() {
        DispatchQueue.main.async {
            if CLLocationManager.locationServicesEnabled() {
                self.locationManager.requestWhenInUseAuthorization()
                self.locationManager.startUpdatingLocation()
            } else {
                // Handle the case where location services are not enabled
            }
        }
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let currentLocation = locations.first else { return }
        DispatchQueue.main.async {
            self.region = MKCoordinateRegion(center: currentLocation.coordinate, latitudinalMeters: 500, longitudinalMeters: 500)
            self.annotations = [AnnotationItem(coordinate: self.destinationCoordinate)]
            self.calculateRoute(from: currentLocation.coordinate)
            self.locationManager.stopUpdatingLocation() // Stop location updates if not needed further
        }
    }

    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        DispatchQueue.main.async {
            self.checkIfLocationServicesIsEnabled()
        }
    }

    private func calculateRoute(from coordinate: CLLocationCoordinate2D) {
        let request = MKDirections.Request()
        request.source = MKMapItem(placemark: MKPlacemark(coordinate: coordinate))
        request.destination = MKMapItem(placemark: MKPlacemark(coordinate: self.destinationCoordinate))
        request.transportType = .automobile

        let directions = MKDirections(request: request)
        directions.calculate { response, error in
            DispatchQueue.main.async {
                if let route = response?.routes.first {
                    self.route = route
                    self.region = MKCoordinateRegion(route.polyline.boundingMapRect)
                }
            }
        }
    }
}

struct ParkingSpotMapView_Previews: PreviewProvider {
    static var previews: some View {
        ParkingSpotMapView()
    }
}
