//
//  AddVehicleView.swift
//  ParkiUDLAP
//
//  Created by Aldo Serrano Rugerio on 30/04/24.
//

import SwiftUI

struct AddVehicleView: View 
{
    @State private var VehicleType: String = ""
    @State private var Brand: String = ""
    @State private var Model: String = ""
    @State private var Plates: String = ""
    @State private var OwnersName: String = ""
    @Environment(\.dismiss) var dismiss
    @EnvironmentObject var viewModel: AuthViewModel
    @StateObject var vehicleViewModel = VehicleViewModel()
    var body: some View
    {
        NavigationStack
        {
            ZStack
            {
                LogInBackgroundView(offsetY: 100)
                VStack
                {
                    HStack
                    {
                        
                        Button
                        {
                            dismiss()
                        }
                        label:
                        {
                            Image(systemName: "chevron.backward")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 30, height: 30)
                                .foregroundStyle(.white)
                                .padding(.leading, 40)
                                .padding(.trailing, 30)
                        }
                        
                        Text("Registrar Vehiculo")
                            .font(.title)
                            .bold()
                            .foregroundStyle(.white)
                        
                        Spacer()
                    }
                    .padding(.top, 40)
                    .padding(.bottom, 40)
                    
                    SingleSelectionView(VehicleType: $VehicleType)
                    
                    InputTextView(text: $Brand, title: "Brand", placeholder: "Marca")
                        .padding(.bottom, 5)
                    
                    InputTextView(text: $Model, title: "Model", placeholder: "Modelo")
                        .padding(.bottom, 5)
                        .textInputAutocapitalization(.never)
                    
                    InputTextView(text: $Plates, title: "CarPlates", placeholder: "Placas")
                        .padding(.bottom, 5)
                    
                    InputTextView(text: $OwnersName, title: "OwnersName", placeholder: "Nombre del Propietario")
                        .padding(.bottom, 5)
                    
                    Button
                    {
                        //TODO: Register all data an send it to the database
                        vehicleViewModel.addVehicle(VehicleType: VehicleType, Brand: Brand, Model: Model, Plates: Plates, OwnersName: OwnersName)
                        dismiss()
                    }
                    label:
                    {
                        HStack
                        {
                            Text("Guardar")
                                .fontWeight(.semibold)
                            Image(systemName: "arrow.forward.circle")
                        }
                    }
                    .foregroundStyle(.white)
                    .frame(width: (UIScreen.current?.bounds.width)! - 50, height: 50)
                    .background(AppColors.UDLAPOrange)
                    .disabled(!formIsValid)
                    .opacity(formIsValid ? 1.0 : 0.5)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                    .shadow(radius: 20)
                    .padding(.top, 40)
                    
                    
                    Spacer()
                }
            }
        }
        .navigationBarBackButtonHidden()
    }
}

#Preview 
{
    AddVehicleView()
}

// MARK: - AuthenticationFormProtocol

extension AddVehicleView: AuthenticationFormProtocol
{
    var formIsValid: Bool
    {
        return !Brand.isEmpty && !Model.isEmpty && !Plates.isEmpty && !OwnersName.isEmpty
    }
}

struct SingleSelectionView: View 
{
    @State private var SelectedOption: Int = 1
    @Binding var VehicleType: String

    var body: some View 
    {
        HStack 
        {
            ForEach(0..<3) 
            {
                index in
                Button(action: {
                    // Esto asegura que solo un botón pueda estar seleccionado a la vez
                    SelectedOption = index
                    switch index
                    {
                    case 0:
                        VehicleType = "Motocicleta"
                    case 1:
                        VehicleType = "Auto"
                    case 2:
                        VehicleType = "SUV"
                    default:
                        VehicleType = ""
                    }
                }) {
                    switch index
                    {
                    case 0:
                        Image(systemName: "bicycle")
                    case 1:
                        Image(systemName: "car")
                    case 2:
                        Image(systemName: "suv.side")
                    default:
                        Text("")
                    }
                }
                .buttonStyle(PlainButtonStyle())
                .modifier(BoxToggleStyle(isSelected: SelectedOption == index))
            }
        }
    }
}

struct BoxToggleStyle: ViewModifier 
{
    var isSelected: Bool

    func body(content: Content) -> some View 
    {
        content
            .frame(width: 60, height: 60)
            .background(isSelected ? AppColors.UDLAPOrange : .white)
            .foregroundColor(isSelected ? .white : .black)
            .clipShape(RoundedRectangle(cornerRadius: 10))
            .padding()
    }
}
