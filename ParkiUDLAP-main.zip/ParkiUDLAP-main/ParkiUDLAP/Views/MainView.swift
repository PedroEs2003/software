//
//  MainView.swift
//  ParkiUDLAP
//
//  Created by Aldo Serrano Rugerio on 26/04/24.
//

import SwiftUI
import LocalAuthentication

struct MainView: View
{
    @EnvironmentObject var viewModel: AuthViewModel
    var body: some View
    {
        Group
        {
            if (viewModel.userSession != nil)
            {
                MenuView()
            }
            else
            {
                LogInView()
            }
        }
    }
}

#Preview
{
    MainView()
        .environmentObject(AuthViewModel())
}

