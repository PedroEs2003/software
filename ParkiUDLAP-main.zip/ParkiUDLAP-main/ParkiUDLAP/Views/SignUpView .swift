//
//  SignUpView .swift
//  ParkiUDLAP
//
//  Created by Aldo Serrano Rugerio on 23/04/24.
//

import SwiftUI

struct SignUpView: View
{
    @State private var userID: String = ""
    @State private var email: String = ""
    @State private var name: String = ""
    @State private var password: String = ""
    @State private var passConfirmation: String = ""
    @Environment(\.dismiss) var dismiss
    @EnvironmentObject var viewModel: AuthViewModel
    var body: some View
    {
        ZStack
        {
            LogInBackgroundView(offsetY: 100)
            VStack
            {
                HStack
                {
                    
                    Button
                    {
                        dismiss()
                    }
                    label:
                    {
                        Image(systemName: "chevron.backward")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 30, height: 30)
                            .foregroundStyle(.white)
                            .padding(.leading, 40)
                            .padding(.trailing, 70)
                    }
                    
                    Text("Registarse")
                        .font(.title)
                        .bold()
                        .foregroundStyle(.white)
                    
                    Spacer()
                }
                .padding(.top, 40)
                .padding(.bottom, 40)
                    
        
                Text("Sign Up")
                    .font(.title)
                
                InputTextView(text: $userID, title: "ID", placeholder: "ID")
                    .padding(.bottom, 5)
                
                InputTextView(text: $email, title: "Name", placeholder: "Email")
                    .padding(.bottom, 5)
                    .textInputAutocapitalization(.never)
                
                InputTextView(text: $name, title: "LastName", placeholder: "Nombre y Apellidos")
                    .padding(.bottom, 5)
                
                InputTextView(text: $password, title: "Password", placeholder: "Constraseña", isSecureField: true)
                    .padding(.bottom, 5)
                
                ZStack(alignment: .trailing)
                {
                    InputTextView(text: $passConfirmation,
                                  title: "Confirmar contraseña",
                                  placeholder: "Confirma tu contraseña",
                                  isSecureField: true)
                    if (!password.isEmpty && !passConfirmation.isEmpty)
                    {
                        if (password == passConfirmation)
                        {
                            Image(systemName: "checkmark.circle.fill")
                                .imageScale(.small)
                                .fontWeight(.bold)
                                .foregroundStyle(Color(.systemGreen))
                            
                        }
                        else
                        {
                            Image(systemName: "xmark.circle.fill")
                                .imageScale(.small)
                                .fontWeight(.bold)
                                .foregroundStyle(Color(.systemRed))
                        }
                    }
                }
                
                Button
                {
                    Task
                    {
                        try await viewModel.createUser(withEmail: email,
                                                       password: password,
                                                       name: name,
                                                       userID: userID)
                    }
                }
                label:
                {
                    HStack
                    {
                        Text("Continuar")
                            .fontWeight(.semibold)
                        Image(systemName: "arrow.forward.circle")
                    }
                }
                .foregroundStyle(.white)
                .frame(width: (UIScreen.current?.bounds.width)! - 50, height: 50)
                .background(AppColors.UDLAPOrange)
                .disabled(!formIsValid)
                .opacity(formIsValid ? 1.0 : 0.5)
                .clipShape(RoundedRectangle(cornerRadius: 10))
                .shadow(radius: 20)
                .padding(.top, 40)
                
                
                Spacer()
            }
        }
    }
}

#Preview 
{
    SignUpView()
}

// MARK: - AuthenticationFormProtocol

extension SignUpView: AuthenticationFormProtocol
{
    var formIsValid: Bool
    {
        return !email.isEmpty && email.contains("@") && !password.isEmpty
        && password.count > 5 && passConfirmation == password && !name.isEmpty
    }
}
