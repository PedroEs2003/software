//
//  ReportView.swift
//  ParkiUDLAP
//
//  Created by Cecilia Soriano Tochimani on 29/04/24.
//

import SwiftUI

struct ReportView: View {
    @State private var reporte: String = ""
    var body: some View {
        ZStack{
            Color(red:255/255, green: 250/255, blue: 250/250)
                .edgesIgnoringSafeArea(.all)
            VStack{
                Text("Hacer Reporte")
                    .font(.title)
                    .fontWeight(.bold)
                    .padding(.trailing, 150)
                    .padding(.bottom, 50.0)
                    .foregroundColor(.black)
                    
              
                Text("Describe el problema")
                    .padding(.trailing, 150.0)
                TextField("", text: $reporte)
                    .padding(.horizontal, 20) // Agregar relleno horizontal
                    .padding(.vertical, 200.0) // Reducir el relleno vertical
                    .background(Color.white)
                    .cornerRadius(20)
                    .padding(.horizontal, 30)
                
                HStack{
                    Image(systemName: "square.and.arrow.up")
                        .imageScale(.large)
                        .foregroundStyle(.black)
                    Image(systemName: "trash")
                        .imageScale(.large)
                        .foregroundStyle(.black)
                }
                .padding(.top, 20)
                .padding(.trailing, 250)
                
                Button(action: {
                    // Acción a realizar cuando se presiona el botón
                }) {
                    Text("Enviar reporte")
                        .foregroundColor(.white)
                        .padding()
                        .background(Color(red: 26/255, green: 93/255, blue: 26/255))
                        .cornerRadius(10)
                }
                
            }//VSTACK
        }//ZSTACK
    }
}

#Preview {
    ReportView()
}
