//
//  MapView.swift
//  ParkiUDLAP
//
//  Created by Aldo Serrano Rugerio on 06/05/24.
//

import SwiftUI
import MapKit

struct MapView: View {
    @State private var region = MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: 19.053, longitude: -98.283), span: MKCoordinateSpan(latitudeDelta: 0.003, longitudeDelta: 0.003))

    var body: some View {
            NavigationView {
                VStack {
                    ZStack {
                        Map(coordinateRegion: $region, showsUserLocation: true, userTrackingMode: .constant(.follow))
                            .frame(maxWidth: .infinity, maxHeight: .infinity)
                            .ignoresSafeArea()
                            .disabled(true)
                        
                        VStack {
                            VStack {
                                Spacer()
                                
                                NavigationLink(){
                                    
                                }label: {
                                    Image(systemName: "mappin.circle.fill")
                                        .font(.system(size: 32))
                                        .foregroundStyle(Color.green)
                                }
                                .padding(.top, 100)
                                
                                Spacer()
                                
                                NavigationLink(){
                                    
                                }label: {
                                    Image(systemName: "mappin.circle.fill")
                                        .font(.system(size: 32))
                                        .foregroundStyle(Color.red)
                                }
                                .padding(.trailing, 200)
                                
                                Spacer()
                                
                                NavigationLink(destination: Text("Yellow Pin View")) {
                                    Image(systemName: "mappin.circle.fill")
                                        .font(.system(size: 32))
                                        .foregroundStyle(Color.yellow)
                                }
                                .padding(.leading, 200)
                                
                                ZStack {
                                    RoundedRectangle(cornerRadius: 30)
                                        .fill(Color.white)
                                        .frame(width: 350, height: .infinity)
                                        .padding(.top, 200)
                                    
                                    ScrollView {
                                        ForEach(parkList, id: \.id) { item in
                                            MiniParkCard(park: item)
                                        }
                                    }
                                    .frame(width: 350, height: 400)
                                    .padding(.top, 220)
                                }
                            }
                        }
                    }
                }
            }
        }
    }


struct MiniParkCard: View {
    var park: Park
    
    var body: some View {
        NavigationLink{
            ParkingSpotView(park: park)
        }label:{
            ZStack {
                HStack {
                    Image(park.image)
                        .resizable()
                        .scaledToFill()
                        .frame(width: 85, height: 70)
                        .clipShape(RoundedRectangle(cornerRadius: 13))
                        .padding(.leading, 10)
                    VStack(alignment: .leading) {
                        Text("\(park.name)")
                            .font(.system(size: 25, weight: .semibold))
                            .foregroundStyle(AppColors.UDLAPGreen)
                        
                        Text("\(park.name)")
                            .font(.system(size: 20, weight: .regular))
                            .foregroundStyle(AppColors.UDLAPOrange)
                    }
                    Spacer()
                    VStack() {
                        Text("Espacios")
                            .font(.system(size: 15, weight: .regular))
                            .foregroundStyle(AppColors.UDLAPOrange)
                        
                        Text("10")
                            .font(.system(size: 20, weight: .regular))
                            .foregroundStyle(AppColors.UDLAPOrange)
                    }
                    .padding(.trailing)
                }
                .frame(width: 350, height: 95)
            }
            .frame(width: 320, height: 95)
            .background(Color.gray.opacity(0.1))
            .clipShape(RoundedRectangle(cornerRadius: 25.0))
            .padding(3)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        MapView()
    }
}

