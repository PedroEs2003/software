//
//  TicketView.swift
//  ParkiUDLAP
//
//  Created by Aldo Serrano Rugerio on 06/05/24.
//

import SwiftUI

struct TicketView: View 
{
    @Environment(\.dismiss) var dismiss
    var body: some View
    {
        VStack
        {
            Text("Pagar Boleto")
                .font(.title)
                .bold()
            Image("Boleto")
                .resizable()
                .scaledToFit()
                .frame(width: 250, height: 250)
            HStack
            {
                Text("Información de pago")
                    .padding(.leading)
                Spacer()
                Text("Editar")
                    .padding(.trailing)
            }
            
            NavigationLink(destination: AddPaymentView())
            {
                HStack{
                    Image(systemName: "plus")
                        .imageScale(.large)
                        .foregroundStyle(.black)
                    Text("Añadir método de pago")
                        .padding(.trailing, 120.0)
                }
                .padding(.top, 10)
            }
            
            HStack
            {
                Text("Total")
                    .padding(.leading)
                Spacer()
                Text("$18.00")
                    .padding(.trailing)
            }
            .padding()
            
            Button
            {
                //TODO: Charge the user the price of the ticket
                dismiss()
            }
            label:
            {
                HStack
                {
                    Text("Pagar")
                        .fontWeight(.semibold)
                    Image(systemName: "arrow.forward.circle")
                }
            }
            .foregroundStyle(.white)
            .frame(width: (UIScreen.current?.bounds.width)! - 50, height: 50)
            .background(AppColors.UDLAPOrange)
            .clipShape(RoundedRectangle(cornerRadius: 10))
            .shadow(radius: 20)
            .padding(.top, 40)
            
            Spacer()
        }
    }
}

#Preview {
    TicketView()
}
