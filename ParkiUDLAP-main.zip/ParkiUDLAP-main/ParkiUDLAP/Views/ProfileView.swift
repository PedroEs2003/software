//
//  ProfileView.swift
//  ParkiUDLAP
//
//  Created by Cecilia Soriano Tochimani on 28/04/24.
//

import SwiftUI

struct ProfileView: View
{
    @EnvironmentObject var viewModel: AuthViewModel
    @Environment(\.dismiss) var dismiss
    var body: some View
    {
        if let user = viewModel.currentUser
        {
            NavigationStack{
                ZStack{
                    Color(red: 26/255, green: 93/255, blue: 26/255)
                        .edgesIgnoringSafeArea(.all)
                    VStack{
                        HStack
                        {
                            Button
                            {
                                dismiss()
                            }
                            label:
                            {
                                Image(systemName: "chevron.backward")
                            }
                            Text("Perfil")
                                .font(.title)
                                .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
                        }
                        .padding(.trailing, 280)
                        .padding(.bottom, 10.0)
                        .foregroundColor(.white)
                        .padding(.top, 80)
                        ZStack{
                            Circle()
                                .frame(width: 160,height: 160)
                                .foregroundColor(.white)
                                .offset(y:8)
                            Image("pimienta")
                                .resizable()
                                .frame(width: 150,height: 150)
                                .clipShape(Circle())
                                .aspectRatio(contentMode: .fill)
                                .padding(.top)
                        }
                        Text(user.name)
                            .font(.title)
                            .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
                            .padding(.trailing, 0)
                            .foregroundColor(.white)
                        Text(user.userID)
                            .font(.title2)
                            .foregroundColor(.white)
                        Text("Alumno")
                            .foregroundColor(.white)
                        
                       
                        
                        VStack{
                            HStack{
                                Image(systemName: "pencil.line")
                                    .imageScale(.large)
                                    .foregroundStyle(.black)
                                Text("Editar información")
                                    .padding(.trailing, 150.0)
                            }
                            .padding(.top, 40)
                           
                            HStack{
                                Image(systemName: "gearshape.fill")
                                    .imageScale(.large)
                                    .foregroundStyle(.black)
                                Text("Ajustes")
                                    .padding(.trailing, 230.0)
                                    
                            }
                            .padding(.top, 10)
                            HStack{
                                Image(systemName: "questionmark.circle.fill")
                                    .imageScale(.large)
                                    .foregroundStyle(.black)
                                Text("Ayuda")
                                    .padding(.trailing, 240.0)
                                    
                               
                            }
                            .padding(.top, 10)
                            Button
                            {
                                viewModel.signOut()
                            }
                            label:
                            {
                                HStack{
                                    Image(systemName: "xmark.circle")
                                        .imageScale(.large)
                                        .foregroundStyle(.black)
                                    Text("Cerrar Sesión")
                                        .padding(.trailing, 185.0)
                                }
                                .padding(.top, 10)
                            }
                            .tint(.black)
                            
                            Divider()
                            NavigationLink(destination: VehicleView()){
                                HStack{
                                    Image(systemName: "car")
                                        .imageScale(.large)
                                        .foregroundStyle(.black)
                                    Text("Mis vehiculos")
                                        .padding(.trailing, 210.0)
                                        .padding(.bottom, 10.0)
                                       
                                    
                                }
                                .padding(.top, 10)
                            }
                            NavigationLink(destination: AddVehicleView()){
                                HStack{
                                    Image(systemName: "plus")
                                        .imageScale(.large)
                                        .foregroundStyle(.black)
                                    Text("Añadir auto")
                                        .padding(.trailing, 210.0)
                                        .padding(.bottom, 10.0)
                                       
                                    
                                }
                                .padding(.top, 10)
                            }
                            NavigationLink(destination: AddPaymentView()){
                                HStack{
                                    Image(systemName: "plus")
                                        .imageScale(.large)
                                        .foregroundStyle(.black)
                                    Text("Añadir método de pago")
                                        .padding(.trailing, 120.0)
                                }
                                .padding(.top, 10)
                            }
                        Spacer()
                            
                            
                        }
                        .frame(width: .infinity, height: 480)
                        .background(Color(.white))
                        .cornerRadius(20)
                        .shadow(radius: 3)
                        .padding(.bottom,10)
                        
                    }//VSTACK
                    
                }//ZSTACK
                
            }//NAVIGATION STACK
            .navigationBarBackButtonHidden()
            .tint(.black)
            
        }
    }
}

#Preview
{
    ProfileView()
        .environmentObject(AuthViewModel())
}
